package Modelo;
public class TipoCuenta {
    private String descripcion; //puede que este mal

    public TipoCuenta(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }
}

