package Modelo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

public class CuentaUsuario {
    private String nombre; 
    private String apellido;
    private String documento;
    private Double saldo;
    private TipoUsuario tipoUsuario;
    private TipoCuenta tipoCuenta;
    private Cobro cobro;

    public CuentaUsuario(String nombre, String apellido, String documento, Double saldo, TipoUsuario tipoUsuario, TipoCuenta tipoCuenta, Cobro cobro) {
        this.tipoUsuario = tipoUsuario;
        this.tipoCuenta = tipoCuenta;
        this.cobro = cobro;
        // Se asegura que el saldo sea 0.0 si es nulo, para evitar NullPointerExceptions.
        this.saldo = saldo != null ? saldo : 0.0;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documento = documento;
    }
    
    //GETTERS DE LOS DATOS//
    public double getSaldo(){
        return saldo;
    }
    public String getNombre(){
        return nombre;
    }
    public String getApellido(){
        return apellido;
    }
    public String getDocumento(){
        return documento;
    }
    public TipoUsuario getTipoUsuario() {
        return tipoUsuario;
    }
    public TipoCuenta getTipoCuenta() {
        return tipoCuenta;
    }
    public CuentaUsuario getCuentaUsuario(){
        return this;
    }
   
    //SETTERS DE LOS DATOS//
    public void setSaldo(Double saldo){
        this.saldo = saldo;
    }
    

    
    
    //METODOS//
    // Constante para la ruta del archivo
    private static final String NOMBRE_ARCHIVO = "C:\\Users\\Rodrigo\\Desktop\\TPI-Estacionamiento\\TPI-Estacionamiento\\src\\main\\java\\Recursos\\CreacionDeUsuario.txt";
    public void registrarCuenta(){
        // 1. Formatear la línea de datos para guardar. Usamos la coma (,) como separador.
        String lineaDatos = getNombre() + "," +
                            getApellido() + "," +
                            getDocumento() + "," +
                            getSaldo();
        
        // 2. Lógica de escritura del archivo
        try (PrintWriter writer = new PrintWriter(new FileWriter(NOMBRE_ARCHIVO, true))) {
            
            // El 'true' en FileWriter(NOMBRE_ARCHIVO, true) indica modo de APENDIZADO (añadir al final)
            // Esto evita que se sobrescriban los datos existentes.
            
            writer.println(lineaDatos); //Escribimos

        } catch (IOException e) {
            System.err.println("❌ ERROR al guardar la cuenta en el archivo: " + e.getMessage());
        }
    }
        
    //pertenece a la clase misma, y no a una instancia específica (objeto) de esa clase.

    public static boolean recargarSaldo(String documento, double montoAAgregar) throws IOException {

        // Obtener la ruta (Path) del archivo
        Path path = Paths.get(NOMBRE_ARCHIVO);

        // 1. Leer todas las líneas del archivo en una lista (sustituye a leerTodasLasLineas())
        List<String> lineas = Files.readAllLines(path);
        List<String> nuevasLineas = new ArrayList<>();
        boolean cuentaEncontrada = false;

        for (String linea : lineas) {
            String[] datos = linea.split(",");

            // Asumiendo que Documento está en datos[2] y Saldo en datos[3]
            if (datos.length >= 4 && datos[2].trim().equals(documento)) {

                // Cuenta encontrada: Actualizar saldo
                try {
                    double saldoActual = Double.parseDouble(datos[3].trim());
                    double nuevoSaldo = saldoActual + montoAAgregar;

                    // Crear la nueva línea con el saldo actualizado
                    // NOTA: Ajusta los índices si tienes más o menos campos después del saldo.
                    // Asumo: Nombre, Apellido, Documento, Saldo, TipoUsuario, TipoCuenta
                    String nuevaLinea = datos[0] + "," + datos[1] + "," + datos[2] + "," + nuevoSaldo;

                    nuevasLineas.add(nuevaLinea);
                    cuentaEncontrada = true;

                } catch (NumberFormatException e) {
                    // Si el saldo no era un número, copiamos la línea vieja y registramos error
                    System.err.println("Error: Saldo guardado con formato incorrecto. " + e.getMessage());
                    nuevasLineas.add(linea); 
                }

            } else {
                // Si no es la línea buscada, la copiamos tal cual.
                nuevasLineas.add(linea);
            }
        }

        if (cuentaEncontrada) {
            // 2. Sobrescribir el archivo completo con las líneas modificadas
            // Files.write(path, nuevasLineas) sobrescribe por defecto el archivo existente.
            Files.write(path, nuevasLineas);
            return true;
        }

        return false; // Cuenta no encontrada.
    }
    public void descontarMonto(Double monto){
        if(monto > 0){
            setSaldo(monto);
        }
    }
    
    public static Double consultarSaldo(String documento) throws IOException {
        
        // Usamos try-with-resources para asegurar que el archivo se cierre.
        try (BufferedReader br = new BufferedReader(new FileReader(NOMBRE_ARCHIVO))) {
            String linea;
            
            // Lee el archivo línea por línea hasta el final.
            while ((linea = br.readLine()) != null) {
                
                // Divide la línea usando la coma (,) como separador.
                String[] datos = linea.split(",");
                
                // Verificamos si la línea tiene al menos 4 partes (nombre, apellido, doc, saldo)
                // y si el documento coincide (asumiendo que el documento está en la posición [2])
                if (datos.length >= 4 && datos[2].trim().equals(documento)) {
                    
                    try {
                        // El saldo es el cuarto elemento (índice 3).
                        return Double.parseDouble(datos[3].trim());
                    } catch (NumberFormatException e) {
                        // Ocurre si el saldo guardado no es un número válido.
                        System.err.println("Error de formato de saldo en la línea: " + linea);
                        return null; 
                    }
                }
            }
        }
        
        // Retorna null si el bucle termina y el documento no fue encontrado.
        return null; 
    }
    
    public Double conocerCobro(Cobro cobro){
        if(cobro != null){
            return cobro.getMonto();
        }else{
            return null;
        }
    }
    public String conocerTipoCuenta(TipoCuenta cuenta){
        if(cuenta != null){
            return cuenta.getDescripcion();
        }else{
            return null;
        }
    }
    public boolean pagar(Cobro cobro){
        if(getCuentaUsuario() != null){
            if(getSaldo()>cobro.getMonto()){
                boolean pagado;
                pagado = cobro.isPagado();
                return pagado;
            }
        }
        return false;
    }
    
    /*public void consultarAfiliadoUTN() {
        // Simulación de consulta
        // La vista debe encargarse de mostrar mensajes de consulta y verificación de afiliación
        afiliadoUTN = true;
    }*/
    
    /*public void concerVehiculo(Vehiculo vehiculo) {
        // Simulación de consulta
        // La vista debe encargarse de mostrar mensajes de consulta y verificación de afiliación
        return vehiculo.getModelo();
    }*/
    
    //registrarUsuario? va esto aca?
}