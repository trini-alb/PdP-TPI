package Modelo;

public enum Estado {
    DISPONIBLE,
    OCUPADA;
}
